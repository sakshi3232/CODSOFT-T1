from flask import Flask, render_template, request, jsonify
from datetime import datetime
import random

app = Flask(__name__)

#chatbot logic 
def get_chatbot_response(user_input):
    user_input = user_input.lower()  

    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you?"
    
    elif "how are you" in user_input:
        return "I'm just a bot, but I'm doing great! How about you?"
    
    elif "bye" in user_input:
        return "Goodbye! Have a great day!"
    
    elif "your name" in user_input or "what's your name" in user_input:
        return "I am a friendly chatbot created to assist you!"
    
    elif "favorite color" in user_input:
        return "My favorite color is blue! It's calm and peaceful."
    
    elif "joke" in user_input:
        jokes = [
            "Why don't skeletons fight each other? They don't have the guts!",
            "Why don’t eggs tell jokes? They might crack up!",
            "I told my wife she was drawing her eyebrows too high. She looked surprised!"
        ]
        return random.choice(jokes)
    
    elif "random fact" in user_input:
        facts = [
            "Did you know that honey never spoils? Archaeologists have found pots of honey in ancient tombs that are over 3,000 years old!",
            "A group of flamingos is called a 'flamboyance'!",
            "Bananas are berries, but strawberries are not!"
        ]
        return random.choice(facts)

    elif "how old are you" in user_input:
        return "I don't have an age, but I was created to assist you and have fun chatting!"
    
    elif "how was your day" in user_input:
        return "My day is always great, assisting you is the highlight of my existence!"
    
    elif "favorite activity" in user_input:
        return "I love chatting with you! That's my favorite activity."
    
    elif "quote" in user_input:
        quotes = [
            "Believe you can and you're halfway there.",
            "The only way to do great work is to love what you do.",
            "Success is not final, failure is not fatal: It is the courage to continue that counts."
        ]
        return random.choice(quotes)

    elif "advice" in user_input:
        return "Always stay positive and keep pushing forward, no matter the challenges."

    elif "date" in user_input or "what's the date" in user_input:
        current_date = datetime.now().strftime("%B %d, %Y")
        return f"Today is {current_date}."
    
    elif "day" in user_input or "what's the day" in user_input:
        current_day = datetime.now().strftime("%A")  # Get the full day (e.g., Friday)
        return f"Today is {current_day}."

    elif "compliment" in user_input:
        return "You're awesome! Keep being amazing!"

    elif "help" in user_input:
        return ("I can assist with a variety of things:\n"
                "- I can tell you jokes or random facts\n"
                "- I can share motivational quotes\n"
                "- I can answer questions about the date and time\n"
                "- I can give advice and much more!")

    elif "weather" in user_input:
        return "Sorry, I don't have real-time weather information at the moment."
    
    elif "time" in user_input:
        current_time = datetime.now().strftime("%H:%M:%S")
        return f"The current time is {current_time}"
    
    else:
        return "I'm sorry, I don't understand that. Can you ask something else?"

#homepage
@app.route('/')
def home():
    return render_template('index.html')

#route
@app.route('/get_response', methods=['POST'])
def get_response():
    user_input = request.form['user_input']
    response = get_chatbot_response(user_input)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)
